package com.muvraline.authenticationserver;

import static com.muvraline.authenticationserver.AuthenticationserverApplication.ENV_TYPE;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClients;

@Configuration
@EnableMongoAuditing
public class MongoConfig extends AbstractMongoClientConfiguration {

	@Value("${mongodb.url}")
	private String url;

	@Value("${spring.data.mongodb.database}")
	private String mongoDB;

	@Bean
	public MongoTemplate mongoTemplate() {
		return new MongoTemplate(mongoClient(), mongoDB);
	}

	@Override
	protected String getDatabaseName() {
		return mongoDB;
	}

	@Bean
	public com.mongodb.client.MongoClient mongoClient() {
		ConnectionString connection = new ConnectionString(url);
		return MongoClients.create(connection);
	}
}
