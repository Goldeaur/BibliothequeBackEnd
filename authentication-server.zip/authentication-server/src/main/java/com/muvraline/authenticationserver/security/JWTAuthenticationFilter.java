package com.muvraline.authenticationserver.security;

import com.muvraline.authenticationserver.WebSecurityConfig;
import com.muvraline.authenticationserver.domain.User;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.MalformedJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

//Peut-être utiliser authenticationManager ?
@Component
@Slf4j
public class JWTAuthenticationFilter extends OncePerRequestFilter {

    private final List<String> toIgnore = Arrays.asList(WebSecurityConfig.noJwtFilter);
    @Autowired
    private JwtUserDetailsService jwtUserDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        final String jwtToken = request.getHeader("jwt");
        User user = null;

        try {
            user = jwtTokenUtil.getUserFromTokenAndValidate(jwtToken);
        } catch (IllegalArgumentException e) {
            log.error("Unable to get JWT Token : {}", e.getMessage());
            throw e;
        } catch (ExpiredJwtException e) {
            log.error("JWT Token has expired : {}", e.getMessage());
            throw e;
        } catch (JwtException e) {
            log.error("JWT Token error : {}", e.getMessage());
            throw e;
        }
        if (user != null) {
            if (user.getAccountId() != null) {
                UserDetails userDetails = this.jwtUserDetailsService.loadByUser(user);
                if (!userDetails.isEnabled())
                    throw new DisabledException("User is disabled");
                if (jwtTokenUtil.validateUserToken(jwtToken, userDetails)) {
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    usernamePasswordAuthenticationToken
                            .setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                }
            } else if (user.getEmail() != null) {
                UserDetails userDetails = this.jwtUserDetailsService.loadSupportByEmail(user.getEmail());
                if (!userDetails.isEnabled())
                    // can support account be disabled
                    throw new DisabledException("User is disabled");
                if (jwtTokenUtil.validateSupportToken(jwtToken, userDetails)) {
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    usernamePasswordAuthenticationToken
                            .setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                }
            }
        } else {
            throw new MalformedJwtException("Could not find expected information in JWT");
        }
        chain.doFilter(request, response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        if(request.getMethod().equals(HttpMethod.OPTIONS.name())){
            return true;
        }
        return toIgnore.stream().anyMatch(path -> request.getRequestURI().startsWith(path));
    }
}
