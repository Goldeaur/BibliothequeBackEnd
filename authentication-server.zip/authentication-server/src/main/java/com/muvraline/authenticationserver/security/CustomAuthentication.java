package com.muvraline.authenticationserver.security;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import lombok.Getter;
import lombok.ToString;

@SuppressWarnings("serial")
@Getter
@ToString
public class CustomAuthentication extends UsernamePasswordAuthenticationToken{
	
	private String password;
	private String login;
	private String agent;
	
	
	public CustomAuthentication(Object principal, Object credentials) {
		super(principal, credentials);
	}

	public CustomAuthentication(String login, String password, String agent) {
		super(login, password);
		this.login = login;
		this.password = password;
		this.agent = agent;
	}
	
}
