package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@Builder
public class JwtRequest {

	private String login;
	private String password;
	private String agent;

	@JsonCreator
	public JwtRequest(@JsonProperty(value = "login", required = true) String login, @JsonProperty(value = "password", required = true) String password, @JsonProperty(value = "agent") String agent) {
		this.login = login;
		this.password = password;
		this.agent = agent;
	}

}