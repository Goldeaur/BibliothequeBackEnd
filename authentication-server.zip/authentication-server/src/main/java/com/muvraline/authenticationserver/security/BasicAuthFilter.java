package com.muvraline.authenticationserver.security;

import static com.muvraline.authenticationserver.AuthenticationserverApplication.ENV_TYPE;
import static com.muvraline.authenticationserver.security.JwtTokenUtil.BASICAUTH;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.muvraline.authenticationserver.domain.Role;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class BasicAuthFilter extends OncePerRequestFilter {

	@Value("${security.username}")
	private String username;
	@Value("${security.password}")
	private String password;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		if (SecurityContextHolder.getContext().getAuthentication() == null || !SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {
			final String authorization = request.getHeader("Authorization");
			if (authorization != null && authorization.toLowerCase().startsWith("basic")) {
				// Authorization: Basic base64credentials
				String base64Credentials = authorization.substring("Basic".length()).trim();
				byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
				String credentials = new String(credDecoded, StandardCharsets.UTF_8);
				// credentials = username:password
				final String[] values = credentials.split(":", 2);
				String username = values[0];
				String password = values[1];
				if (username.equals(this.username) && password.equals(this.password)) {
					List<GrantedAuthority> auths = Arrays.asList(Role.BASIC_AUTH);
					Authentication userDetails = new UsernamePasswordAuthenticationToken(username, password, auths);
					SecurityContextHolder.getContext().setAuthentication(userDetails);
				}
			}
		}

		chain.doFilter(request, response);
	}

}
