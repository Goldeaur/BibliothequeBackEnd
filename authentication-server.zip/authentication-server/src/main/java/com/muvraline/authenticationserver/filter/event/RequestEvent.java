package com.muvraline.authenticationserver.filter.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import lombok.experimental.SuperBuilder;


@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
@JsonInclude(value = Include.ALWAYS)
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(callSuper = true)
public class RequestEvent extends Event{

    @Builder.Default
    private String type = "Request";

    @JsonIgnore
    private Long startTime;
}

