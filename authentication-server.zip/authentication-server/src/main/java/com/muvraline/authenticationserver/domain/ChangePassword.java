package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor
@Getter
@Setter
@Builder
public class ChangePassword {

    @JsonProperty(required = true)
    private String accountId;
    @JsonProperty(required = true)
    private String password;
    private String agent;

    @JsonCreator
    public ChangePassword(@JsonProperty(value = "accountId", required = true) String accountId, @JsonProperty(value = "password", required = true) String password, @JsonProperty(value = "agent") String agent) {
        this.accountId = accountId;
        this.password = password;
        this.agent = agent;
    }

}
