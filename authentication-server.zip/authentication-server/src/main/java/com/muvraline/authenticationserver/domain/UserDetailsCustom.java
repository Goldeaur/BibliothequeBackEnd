package com.muvraline.authenticationserver.domain;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UserDetailsCustom implements UserDetails {

    private static final long serialVersionUID = 1L;

    private User user;

    private Set<? extends GrantedAuthority> authorities = new HashSet<>();


    public UserDetailsCustom(User user) {
        this.user = user;
        this.authorities = new HashSet<>(user.getRoles());
    }

    public UserDetailsCustom(User user, Collection<? extends GrantedAuthority> authorities) {
        this.user = user;
        this.authorities = new HashSet<>(authorities);
    }


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        if (user.getAccountId() != null) {
            return user.getAccountId();
        }
        return user.getEmail();
    }

    public String getEmail() {
        return user.getEmail();
    }

    public LocalDateTime getCreationDate() {
        return user.getCreationDate();
    }

    public List<Role> getRoles() {
        return user.getRoles();
    }

    public String getAgent() {
        return user.getAgent();
    }

    public RgpdChoices getRgpdChoices(){
        return user.getRgpdChoices();
    }

    public boolean isUser() {
        for (Role role: Role.getUserRoles()) {
            if (user.hasRole(role)) {
                return true;
            }
        }
        return false;
    }

    public OpCo getOpco(){
        return user.getOpCo();
    }

    public String getToken() {
        return user.getToken();
    }

    public String getAccountId() {
        return user.getAccountId();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.user.isEnabled();
    }

}
