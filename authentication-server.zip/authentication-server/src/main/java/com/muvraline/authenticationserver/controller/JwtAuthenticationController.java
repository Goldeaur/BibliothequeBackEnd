package com.muvraline.authenticationserver.controller;

import com.muvraline.authenticationserver.domain.JwtRequest;
import com.muvraline.authenticationserver.domain.JwtResponse;
import com.muvraline.authenticationserver.domain.UserDetailsCustom;
import com.muvraline.authenticationserver.security.CustomAuthenticationManager;
import com.muvraline.authenticationserver.security.JwtTokenUtil;
import com.muvraline.authenticationserver.security.JwtUserDetailsService;
import io.jsonwebtoken.JwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin
@Slf4j
public class JwtAuthenticationController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private CustomAuthenticationManager authenticationManager;

    @PostMapping(value = "/authenticate")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
        final UserDetailsCustom userDetails = userDetailsService.loadUserByUsernameAndAgent(authenticationRequest.getLogin(),
                authenticationRequest.getAgent());
        log.info("Trying to connect : {} Agent : {}",userDetails.getAccountId(), userDetails.getAgent());
        authenticationManager.authenticate(userDetails, authenticationRequest.getPassword());
        final JwtResponse token = jwtTokenUtil.generateToken(userDetails);

        userDetailsService.setConnectionDate(userDetails);

        return ResponseEntity.ok(token);
    }

    @PostMapping(value = "/refresh")
    public ResponseEntity<?> refreshToken(@RequestBody JwtResponse refreshRequest) throws Exception {
        if (refreshRequest.getRefreshToken() == null) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(ControllerUtils.jsonErrorFromString("Refresh token missing from body"));
        }
        try {
            final UserDetailsCustom userDetails = userDetailsService.loadUserByRefreshToken(refreshRequest.getRefreshToken());
            authenticationManager.validateUserDetails(userDetails);
            final JwtResponse token = jwtTokenUtil.generateTokenWithRefresh(userDetails, refreshRequest.getRefreshToken());
            userDetailsService.setConnectionDate(userDetails);
            return ResponseEntity.ok(token);
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromString("Account not found : it might not exist anymore"));
        } catch (JwtException e) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(ControllerUtils.jsonErrorFromException(e));
        } catch (DisabledException | BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ControllerUtils.jsonErrorFromException(e));
        }
    }
}
