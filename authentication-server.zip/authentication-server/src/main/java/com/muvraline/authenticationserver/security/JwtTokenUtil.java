package com.muvraline.authenticationserver.security;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.muvraline.authenticationserver.domain.JwtResponse;
import com.muvraline.authenticationserver.domain.User;
import com.muvraline.authenticationserver.domain.UserDetailsCustom;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.JsonWebKeySet;
import org.jose4j.jwk.PublicJsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.Serializable;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class JwtTokenUtil implements Serializable {

    public static final String SYS_ADMIN = "SYS_ADMIN";
    public static final String SUPPORT_ADMIN = "SUPPORT_ADMIN";

    public static final String BASICAUTH = "BASICAUTH";

    public static final String SUPPORT_1 = "SUPPORT_1";
    public static final String SUPPORT_2 = "SUPPORT_2";
    public static final String SUPPORT_3 = "SUPPORT_3";

    public static final String ADMIN = "ADMIN";
    public static final String USER = "USER";
    // 2 hours
    public static final long JWT_TOKEN_VALIDITY = 2 * 60 * 60;
    private static final SignatureAlgorithm algo = SignatureAlgorithm.RS512;
    private static final long serialVersionUID = -2550185165626007488L;
    private static final String issuer = "test@muvraline.fr";
    private static final String TYPEHEADER = "typ";
    private static final String TYPEVALUE = "jwt";
    private static final String KIDHEADER = "kid";
    private KeyPair key;
    @Value("${rsa.key.public}")
    private String publicKey;
    @Value("${rsa.key.private}")
    private String privateKey;
    private String jwks;
    @Value("${rsa.key.kid}")
    private String KID;

    public static String[] getJwtRoles() {
        String[] result = {SYS_ADMIN, ADMIN, USER};
        return result;
    }

    @PostConstruct
    public void init() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKey));
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKey));
            PrivateKey privateK = kf.generatePrivate(privateKeySpec);
            PublicKey publicK = kf.generatePublic(publicKeySpec);
            key = new KeyPair(publicK, privateK);
            RsaJsonWebKey rsaJwk = (RsaJsonWebKey) PublicJsonWebKey.Factory.newPublicJwk(key.getPublic());
            rsaJwk.setKeyId(KID);
            JsonWebKeySet jwksJson = new JsonWebKeySet(rsaJwk);
            jwksJson.getJsonWebKeys().get(0).setAlgorithm("RS512");
            String keyPem = "-----BEGIN RSA PUBLIC KEY-----\n" + publicKey + "\n-----END RSA PUBLIC KEY-----";
            JsonNode json = mapper.readTree(jwksJson.toJson(JsonWebKey.OutputControlLevel.PUBLIC_ONLY));
            ((ObjectNode) json.get("keys").get(0)).put("rsa", keyPem);
            //jwks = jwksJson.toJson(JsonWebKey.OutputControlLevel.PUBLIC_ONLY);
            jwks = json.toString();

        } catch (NoSuchAlgorithmException | InvalidKeySpecException | JoseException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException | GeneralSecurityException e) {
            e.printStackTrace();
        }
    }

    public String generateRefreshToken(UserDetailsCustom userDetails) {
        Map<String, Object> claims = new HashMap<>();
        if (userDetails.getAgent() != null) {
            claims.put("agent", userDetails.getAgent());
        }
        if (userDetails.getAccountId() != null) {
            claims.put("accountId", userDetails.getAccountId());
        }
        claims.put("email", userDetails.getEmail());
        claims.put("type", "refresh_token");
        String refresh_token = doGenerateRefreshToken(claims, userDetails.getUsername());
        return refresh_token;
    }

    public JwtResponse generateToken(UserDetails userDetails) {
        if (userDetails instanceof UserDetailsCustom) {
            UserDetailsCustom custom = (UserDetailsCustom) userDetails;
            String access_token = generateAccessToken(userDetails, custom);
            String refresh_token = generateRefreshToken(custom);
            return JwtResponse.builder().jwttoken(access_token).refreshToken(refresh_token).build();
        } else {
            return null;
        }
    }

    public JwtResponse generateLinkToken(UserDetails userDetails, String agentUserId) {
        if (userDetails instanceof UserDetailsCustom) {
            UserDetailsCustom custom = (UserDetailsCustom) userDetails;
            Map<String, Object> claims = generateBasicClaims(custom);
            claims.put("agentUserId", agentUserId);
            String access_token = doGenerateAccessToken(claims, custom.getUsername());
            String refresh_token = generateRefreshToken(custom);
            return JwtResponse.builder().jwttoken(access_token).refreshToken(refresh_token).build();
        } else {
            return null;
        }
    }

    public JwtResponse generateLinkTokenWithRefresh(UserDetails userDetails, String refreshToken) {
        if (userDetails instanceof UserDetailsCustom) {
            UserDetailsCustom custom = (UserDetailsCustom) userDetails;
            Map<String, Object> claims = generateBasicClaims(custom);
            Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(refreshToken);
            Claims oldClaims = validateTokenAndGetClaims(jwt);
            claims.put("agentUserId", oldClaims.get("agentUserId"));
            String access_token = doGenerateAccessToken(claims, custom.getUsername());
            return JwtResponse.builder().jwttoken(access_token).refreshToken(refreshToken).build();
        } else {
            return null;
        }
    }
    public JwtResponse generateTokenWithRefresh(UserDetails userDetails, String refreshToken) {
        if (userDetails instanceof UserDetailsCustom) {
            UserDetailsCustom custom = (UserDetailsCustom) userDetails;
            String access_token = generateAccessToken(custom, custom);
            return JwtResponse.builder().jwttoken(access_token).refreshToken(refreshToken).build();
        } else {
            return null;
        }
    }

    private String generateAccessToken(UserDetails userDetails, UserDetailsCustom custom) {
        Map<String, Object> claims = generateBasicClaims(custom);
        return doGenerateAccessToken(claims, userDetails.getUsername());
    }

    private Map<String, Object> generateBasicClaims(UserDetailsCustom custom) {
        Map<String, Object> claims = new HashMap<>();
        if (custom.getAgent() != null) {
            claims.put("agent", custom.getAgent());
        }
        if (custom.getAccountId() != null) {
            claims.put("accountId", custom.getAccountId());
        }
        if (custom.getRgpdChoices() != null){
            claims.put("rgpd", custom.getRgpdChoices().getEnabled());
        }
        if (custom.getOpco() != null){
            claims.put("opCo", custom.getOpco().toString());
        }
        claims.put("email", custom.getEmail());
        claims.put("roles", custom.getRoles());
        claims.put("type", "access_token");
        return claims;
    }

    private String doGenerateAccessToken(Map<String, Object> claims, String subject) {
        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuer(issuer).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
                .signWith(algo, key.getPrivate())
                .setHeaderParam(TYPEHEADER, TYPEVALUE)
                .setHeaderParam(KIDHEADER, KID)
                .compact();
    }

    private String doGenerateRefreshToken(Map<String, Object> claims, String subject) {
        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuer(issuer).setIssuedAt(new Date(System.currentTimeMillis()))
                .signWith(algo, key.getPrivate())
                .setHeaderParam(TYPEHEADER, TYPEVALUE)
                .setHeaderParam(KIDHEADER, KID)
                .compact();
    }

    public Boolean validateUserToken(String token, UserDetails userDetails) {
        Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(token);
        Claims claims = (Claims) jwt.getBody();
        return validateUserClaims(jwt, claims, userDetails);
    }

    public Boolean validateSupportToken(String token, UserDetails userDetails) {
        Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(token);
        if (!(jwt.getBody() instanceof Claims)) {
            return false;
        }
        Claims claims = (Claims) jwt.getBody();
        if (!jwt.getHeader().get("alg").equals(algo.getValue())) {
            return false;
        }
        return validateSupportClaims(jwt, claims, userDetails);
    }

    public User getUserFromTokenAndValidate(String token) {
        Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(token);
        Claims claims = validateTokenAndGetClaims(token);
        if (claims.getExpiration().after(new Date())) {
            final String username = claims.getSubject();
            final String agentName = claims.get("agent", String.class);
            final String email = claims.get("email", String.class);
            return User.builder().accountId(username).agent(agentName).email(email).token(token).build();
        }
        throw new ExpiredJwtException(jwt.getHeader(), claims, "Token expired");
    }

    public User getUserFromRefreshToken(String token) {
        Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(token);
        Claims claims = validateTokenAndGetClaims(jwt);
        if (claims.get("type").equals("refresh_token")) {
            final String username = claims.getSubject();
            final String agentName = claims.get("agent", String.class);
            final String email = claims.get("email", String.class);
            return User.builder().accountId(username).agent(agentName).email(email).build();
        }
        throw new JwtException("Token is not a refresh token");
    }

    private Claims validateTokenAndGetClaims(String token) {
        Jwt jwt = Jwts.parser().setSigningKey(key.getPublic()).parse(token);
        return validateTokenAndGetClaims(jwt);
    }

    private Claims validateTokenAndGetClaims(Jwt jwt) {
        if (!(jwt.getBody() instanceof Claims)) {
            throw new JwtException("Token malformed");
        }
        Claims claims = (Claims) jwt.getBody();
        if (!jwt.getHeader().get("alg").equals(algo.getValue())) {
            throw new JwtException("Token signed with wrong algorithm");
        }
        if (!claims.getIssuer().equals(issuer)) {
            throw new JwtException("Issuer is wrong");
        }
        return claims;
    }

    private void validateClaims(Jwt jwt, Claims claims) {
        if (!claims.getIssuer().equals(issuer)) {
            throw new JwtException("Issuer is wrong");
        }
        if (claims.getExpiration().before(new Date())) {
            throw new ExpiredJwtException(jwt.getHeader(), claims, "Token expired");
        }
    }

    public Boolean validateUserClaims(Jwt jwt, Claims claims, UserDetails userDetails) {
        validateClaims(jwt, claims);
        UserDetailsCustom details = (UserDetailsCustom) userDetails;
        final String username = claims.getSubject();
        final String agentName = claims.get("agent", String.class);
        if (agentName != null && !agentName.equals(details.getAgent())) {
            return false;
        }
        return username.equals(userDetails.getUsername());
    }

    public Boolean validateSupportClaims(Jwt jwt, Claims claims, UserDetails userDetails) {
        validateClaims(jwt, claims);
        final String email = claims.get("email", String.class);
        return email.equals(userDetails.getUsername());
    }

    public String getJwk() {
        return jwks;
    }
}
