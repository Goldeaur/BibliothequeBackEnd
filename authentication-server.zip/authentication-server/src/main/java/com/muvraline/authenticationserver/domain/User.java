package com.muvraline.authenticationserver.domain;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class User extends UserBase {

    @Builder.Default
    protected List<Role> roles = new ArrayList<>();
    protected String token;
    protected String agent;
    protected RgpdChoices rgpdChoices;

    public User(UserAccount userAccount) {
        this.creationDate = userAccount.getCreationDate();
        this.email = userAccount.getEmail();
        this.accountId = userAccount.getAccountId();
        this.password = userAccount.getPassword();
        this.roles = Arrays.asList(userAccount.getRole());
        this.enabled = userAccount.isEnabled();
        this.rgpdChoices = userAccount.getRgpdChoices();
        this.opCo = userAccount.getOpCo();
    }

    public User(SupportAccount supportAccount) {
        this.creationDate = supportAccount.getCreationDate();
        this.email = supportAccount.getEmail();
        this.password = supportAccount.getPassword();
        this.roles = Arrays.asList(supportAccount.getRole());
        this.enabled = supportAccount.isEnabled();
        this.opCo = supportAccount.getOpCo();
    }

    public User(UserAccount userAccount, String agentName) throws UsernameNotFoundException {
        try {
            Agent agent = userAccount.getAgent(agentName);
            this.creationDate = userAccount.getCreationDate();
            this.email = userAccount.getEmail();
            this.accountId = userAccount.getAccountId();
            this.password = agent.getPassword();
            this.roles = agent.getRoles();
            this.agent = agent.getName();
            this.enabled = userAccount.isEnabled();
            this.rgpdChoices = userAccount.getRgpdChoices();
            this.opCo = userAccount.getOpCo();
        } catch (NoSuchElementException e) {
            throw new UsernameNotFoundException("Agent " + agentName + " doesn't exists in account " + userAccount.getAccountId());
        }
    }

    public boolean hasRole(Role role) {
        return roles.contains(role);
    }

}
