package com.muvraline.authenticationserver.oauth2.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.muvraline.authenticationserver.domain.JwtResponse;
import com.muvraline.authenticationserver.domain.Role;
import com.muvraline.authenticationserver.domain.User;
import com.muvraline.authenticationserver.domain.UserDetailsCustom;
import com.muvraline.authenticationserver.oauth2.domain.AuthorizationCodeContent;
import com.muvraline.authenticationserver.oauth2.domain.TokenRequest;
import com.muvraline.authenticationserver.oauth2.domain.TokenResponse;
import com.muvraline.authenticationserver.security.JwtTokenUtil;
import com.muvraline.authenticationserver.security.JwtUserDetailsService;
import com.muvraline.exception.MalformedRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class OAuth2Service {

    @Value("${oauth2.server.google.key}")
    private String GOOGLE_KEY;
    @Value("${oauth2.server.google.secret}")
    private String GOOGLE_SECRET;
    @Value("${oauth2.server.google.redirectUri}")
    private List<String> GOOGLE_REDIRECT_URI;
    @Value("${oauth2.server.amazon.key}")
    private String AMAZON_KEY;
    @Value("${oauth2.server.amazon.secret}")
    private String AMAZON_SECRET;
    @Value("${oauth2.server.amazon.redirectUri}")
    private List<String> AMAZON_REDIRECT_URI;
    @Value("${rsa.key.private}")
    private String privateKeyString;
    @Value("${rsa.key.public}")
    private String publicKeyString;

    private PrivateKey privateKey;
    private PublicKey publicKey;

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private JwtTokenUtil tokenUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    public TokenResponse generateToken(TokenRequest request, String auth) throws MalformedRequestException, JsonProcessingException, UnsupportedEncodingException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        if (request.getClient_id() == null || request.getClient_secret() == null)
            enrichWithClientInfo(request, auth);

        if (request.getGrant_type() != null)
            if (request.getGrant_type().equals("authorization_code")) {
                request.setCode(request.getCode().replaceAll(" ", "+"));
                String agent;
                if (GOOGLE_KEY.equals(request.getClient_id()) && GOOGLE_SECRET.equals(request.getClient_secret()) && GOOGLE_REDIRECT_URI.contains(request.getRedirect_uri()))
                    agent = "google";
                else if (AMAZON_KEY.equals(request.getClient_id()) && AMAZON_SECRET.equals(request.getClient_secret()) && AMAZON_REDIRECT_URI.contains(request.getRedirect_uri()))
                    agent = "amazon";
                else
                    throw new MalformedRequestException("Unknown client");

                AuthorizationCodeContent decryptedCode = decryptCode(request.getCode());
                User user = User.builder()
                        .agent(agent)
                        .roles(Arrays.asList(Role.USER))
                        .accountId(decryptedCode.getAccountId())
                        .build();
                String agentUserId = UUID.randomUUID().toString();
                JwtResponse jwt = tokenUtil.generateLinkToken(new UserDetailsCustom(user), agentUserId);
                return TokenResponse.builder()
                        .access_token(jwt.getJwttoken())
                        .refresh_token(jwt.getRefreshToken())
                        .expires_in(JwtTokenUtil.JWT_TOKEN_VALIDITY)
                        .build();
            } else if (request.getGrant_type().equals("refresh_token")) {
                if (verifyClient(request)) {
                    String refreshToken = request.getRefresh_token();
                    final UserDetailsCustom userDetails = userDetailsService.loadPartnerUserByRefreshToken(refreshToken);
                    final JwtResponse jwt = tokenUtil.generateLinkTokenWithRefresh(userDetails, refreshToken);
                    return TokenResponse.builder()
                            .access_token(jwt.getJwttoken())
                            .refresh_token(jwt.getRefreshToken())
                            .expires_in(JwtTokenUtil.JWT_TOKEN_VALIDITY)
                            .build();
                } else
                    throw new MalformedRequestException("Unknown client");
            }

        throw new MalformedRequestException("Grant type invalid");

    }

    public String getRedirectUri(String clientId, String state, String redirectUri, UserDetailsCustom details) throws MalformedRequestException, BadPaddingException, JsonProcessingException, UnsupportedEncodingException, IllegalBlockSizeException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        return produceUri(getRedirectUriNoCode(clientId, redirectUri, state), "&code=", generateCode(details, clientId));
    }

    @PostConstruct
    public void init() {
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyString));
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyString));
            privateKey = kf.generatePrivate(privateKeySpec);
            publicKey = kf.generatePublic(publicKeySpec);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
        }
    }

    private String decrypt(String msg) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, this.publicKey);
        return new String(cipher.doFinal(org.apache.commons.codec.binary.Base64.decodeBase64(msg)), "UTF-8");
    }

    private AuthorizationCodeContent decryptCode(String code) throws JsonProcessingException, BadPaddingException, UnsupportedEncodingException, IllegalBlockSizeException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        String decrypted = decrypt(code);
        return mapper.readValue(decrypted, AuthorizationCodeContent.class);
    }

    private String encrypt(String msg) throws InvalidKeyException, UnsupportedEncodingException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, this.privateKey);
        return org.apache.commons.codec.binary.Base64.encodeBase64String(cipher.doFinal(msg.getBytes("UTF-8")));
    }

    private void enrichWithClientInfo(TokenRequest request, String auth) {
        String basic = auth.substring(6);
        basic = new String(Base64.getDecoder().decode(basic));
        String[] credentials = basic.split(":");
        request.setClient_id(credentials[0]);
        request.setClient_secret(credentials[1]);
    }

    private String generateCode(UserDetailsCustom details, String clientId) throws BadPaddingException, UnsupportedEncodingException, IllegalBlockSizeException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, JsonProcessingException {
        AuthorizationCodeContent authorizationCodeContent = AuthorizationCodeContent.builder()
                .accountId(details.getAccountId())
                .clientId(clientId)
                .build();
        return encrypt(mapper.writeValueAsString(authorizationCodeContent));
    }

    private String getRedirectUriNoCode(String clientId, String redirectUri, String state) throws MalformedRequestException {
        if (GOOGLE_KEY.equals(clientId) && GOOGLE_REDIRECT_URI.contains(redirectUri))
            return produceUri(redirectUri, "?state=", state);
        if (AMAZON_KEY.equals(clientId) && AMAZON_REDIRECT_URI.contains(redirectUri))
            return produceUri(redirectUri, "?state=", state);
        throw new MalformedRequestException("Unknown client");
    }

    private String produceUri(String base, String paramName, String paramValue) {
        return new StringBuilder().append(base).append(paramName).append(paramValue).toString();
    }

    private boolean verifyClient(TokenRequest request) {
        return (GOOGLE_KEY.equals(request.getClient_id()) && GOOGLE_SECRET.equals(request.getClient_secret())) || (AMAZON_KEY.equals(request.getClient_id()) && AMAZON_SECRET.equals(request.getClient_secret()));
    }


}
