package com.muvraline.authenticationserver.oauth2.controller;


import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.muvraline.authenticationserver.domain.UserDetailsCustom;
import com.muvraline.authenticationserver.oauth2.domain.AuthorizationRequest;
import com.muvraline.authenticationserver.oauth2.domain.RedirectInfo;
import com.muvraline.authenticationserver.oauth2.domain.TokenRequest;
import com.muvraline.authenticationserver.oauth2.domain.TokenResponse;
import com.muvraline.authenticationserver.oauth2.service.OAuth2Service;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/oauth2")
@CrossOrigin
@Slf4j
public class OAuth2Controller {

    @Autowired
    private OAuth2Service service;
    @Autowired
    private ObjectMapper mapper;


    private FormHttpMessageConverter converter = new FormHttpMessageConverter();

    @PostMapping(value = "/authorization")
    public ResponseEntity<RedirectInfo> authorization(@RequestBody AuthorizationRequest request,
                                                      @AuthenticationPrincipal Authentication auth) throws Exception {
        UserDetailsCustom custom = (UserDetailsCustom) auth.getPrincipal();
        String redirect = service.getRedirectUri(request.getClientId(), request.getState(), request.getRedirectUri(), custom);
        return ResponseEntity.ok(RedirectInfo.builder()
                .redirectUri(redirect)
                .build());
    }


    @RequestMapping(path = "/token", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, method = RequestMethod.POST)
    public ResponseEntity<TokenResponse> token(@RequestHeader(value = "authorization", required = false) String auth, InputStream inputStream) throws Exception {

       TokenRequest request = mapper.convertValue(serializeFormData(inputStream), TokenRequest.class);

        log.info("TOKEN REQUEST : " +  request);
        return ResponseEntity.ok(service.generateToken(request, auth));
    }

    @SneakyThrows
    private Map<String, String> serializeFormData(InputStream stream)
    {
        Charset charset =  Charset.defaultCharset();
        String body = StreamUtils.copyToString(stream, Charset.defaultCharset());

        String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
        Map<String, String> result = new HashMap<>();
        for (String pair : pairs) {
            int idx = pair.indexOf('=');
            if (idx == -1) {
                result.put(URLDecoder.decode(pair, charset.name()), null);
            }
            else {
                String name = URLDecoder.decode(pair.substring(0, idx), charset.name());
                String value = URLDecoder.decode(pair.substring(idx + 1), charset.name());
                result.put(name, value);
            }
        }
        return result;
    }
}
