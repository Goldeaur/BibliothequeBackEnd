package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import static com.fasterxml.jackson.annotation.JsonProperty.Access.READ_ONLY;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@ToString
public class UserAccountNoAgent extends UserBase {

    @JsonProperty(required = true)
    protected Country country;

    @Builder.Default
    @JsonProperty(access = READ_ONLY)
    protected Role role = Role.ADMIN;

    @JsonCreator
    public UserAccountNoAgent(@JsonProperty(value = "accountId", required = true) String accountId,
                              @JsonProperty(value = "password", required = true) String password,
                              @JsonProperty(value = "email", required = true) String email,
                              @JsonProperty(value = "country", required = true) Country country,
                              @JsonProperty(value = "opCo", required = true) OpCo opCo,
                              @JsonProperty(value = "enabled", defaultValue = "false") boolean enabled) {
        this.accountId = accountId;
        this.password = password;
        this.email = email;
        this.country = country;
        this.opCo = opCo;
        this.enabled = enabled;
        this.role = Role.ADMIN;
    }

}
