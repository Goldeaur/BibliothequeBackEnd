package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@ToString
@Document("supportAccount")
public class SupportAccount extends BaseInfo {

    @JsonProperty(required = true)
    protected Country country;

    @JsonProperty(required = true)
    protected OpCo opCo;

    @JsonProperty(required = true)
    protected Role role;

    @JsonCreator
    public SupportAccount(@JsonProperty(value = "password", required = true) String password,
                          @JsonProperty(value = "email", required = true) String email,
                          @JsonProperty(value = "country", required = true) Country country,
                          @JsonProperty(value = "opCo", required = true) OpCo opCo,
                          @JsonProperty(value = "role") Role role) {
        this.password = password;
        this.email = email;
        this.country = country;
        this.opCo = opCo;
        this.role = role;
    }
}
