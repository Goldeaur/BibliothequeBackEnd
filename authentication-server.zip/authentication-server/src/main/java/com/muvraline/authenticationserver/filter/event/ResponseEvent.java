package com.muvraline.authenticationserver.filter.event;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonInclude(value = Include.ALWAYS)
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(callSuper = true)
public class ResponseEvent extends Event {

    private int statusCode;

    private long duration;

    @Builder.Default
    private String type = "Response";
}
