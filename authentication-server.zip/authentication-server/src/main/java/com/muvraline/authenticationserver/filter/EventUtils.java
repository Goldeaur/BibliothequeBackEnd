package com.muvraline.authenticationserver.filter;

import com.muvraline.authenticationserver.filter.event.Event;
import com.muvraline.authenticationserver.filter.event.ResponseEvent;
import com.muvraline.authenticationserver.filter.event.RequestEvent;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import static com.muvraline.authenticationserver.filter.LoggerUtils.*;

public class EventUtils {

    static void enrichEventWithContext(Event event, RequestContext context) {
        if (context != null) {
            if (context.getAccountId() != null)
                event.setAccountId(context.getAccountId());
            if (context.getAgent() != null)
                event.setAgent(context.getAgent());
            if (context.getOpCo() != null)
                event.setOpCo(context.getOpCo());
            if (context.getTrigger() != null)
                event.setTrigger(context.getTrigger());
            if (context.getUsurper() != null)
                event.setUsurper(context.getUsurper());
        }
    }

    static void enrichEventBuilderWithContext(Event.EventBuilder eventBuilder, RequestContext context) {
        if (context != null) {
            if (context.getAccountId() != null)
                eventBuilder.accountId(context.getAccountId());
            if (context.getAgent() != null)
                eventBuilder.agent(context.getAgent());
            if (context.getOpCo() != null)
                eventBuilder.opCo(context.getOpCo());
            if (context.getTrigger() != null)
                eventBuilder.trigger(context.getTrigger());
            if (context.getUsurper() != null)
                eventBuilder.usurper(context.getUsurper());
        }
    }

    static void enrichResponseEventWithRequestEvent(ResponseEvent.ResponseEventBuilder responseEventBuilder, RequestEvent requestEvent) {
        if(requestEvent.getAccountId() != null)
            responseEventBuilder.accountId(requestEvent.getAccountId());
        if(requestEvent.getAgent() != null)
            responseEventBuilder.agent(requestEvent.getAgent());
        if(requestEvent.getOpCo() != null)
            responseEventBuilder.opCo(requestEvent.getOpCo());
        if(requestEvent.getRequestId() != null)
            responseEventBuilder.requestId(requestEvent.getRequestId());
        if(requestEvent.getStartTime() != null)
            responseEventBuilder.duration(System.currentTimeMillis() - requestEvent.getStartTime());
        else
            responseEventBuilder.duration(UNKNOWN_DURATION);
        if(requestEvent.getHttpMethod() != null)
            responseEventBuilder.httpMethod(requestEvent.getHttpMethod());
        if(requestEvent.getLocation() != null)
            responseEventBuilder.location(requestEvent.getLocation());
        if (requestEvent.getTrigger() != null)
            responseEventBuilder.trigger(requestEvent.getTrigger());
        if (requestEvent.getUsurper() != null)
            responseEventBuilder.usurper(requestEvent.getUsurper());
    }


    @SuppressWarnings("rawtypes")
    static RequestEvent buildRequestEvent(HttpServletRequestWrapper cashRequest, RequestContext context) {
        RequestEvent.RequestEventBuilder builder = RequestEvent.builder();
        String location = cashRequest.getRequestURI();
        if (cashRequest != null) {
            EventUtils.enrichEventBuilderWithContext(builder, context);
            builder.httpMethod(cashRequest.getMethod().toString());
            builder.location(location);
            String accountId = cashRequest.getHeader(ACCOUNTID_HEADER);
            if (accountId != null)
                builder.accountId(accountId);

            String agent = cashRequest.getHeader(AGENT_HEADER);
            if (agent != null)
                builder.agent(agent);

            String requestId = cashRequest.getHeader(XREQUESTID);
            if (requestId != null)
                builder.requestId(requestId);

            builder.startTime(System.currentTimeMillis());
        }
        return builder.build();
    }

    @SuppressWarnings("rawtypes")
    static ResponseEvent buildResponseEvent(HttpServletResponse response, RequestEvent requestEvent) {
        ResponseEvent.ResponseEventBuilder builder = ResponseEvent.builder();
        if (response != null) {
            EventUtils.enrichResponseEventWithRequestEvent(builder, requestEvent);
            builder.statusCode(response.getStatus());
        }

        return builder.build();
    }

    public static RequestEvent buildRequestEvent(HttpServletRequestWrapper cashRequest){
        return buildRequestEvent(cashRequest, LoggerUtils.getContext(cashRequest.getHeader(XCONTEXT)));
    }

}
