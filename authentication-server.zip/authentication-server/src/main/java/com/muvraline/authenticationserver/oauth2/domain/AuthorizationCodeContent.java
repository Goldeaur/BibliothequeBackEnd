package com.muvraline.authenticationserver.oauth2.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class AuthorizationCodeContent {

    private String accountId;
    private String clientId;

}
