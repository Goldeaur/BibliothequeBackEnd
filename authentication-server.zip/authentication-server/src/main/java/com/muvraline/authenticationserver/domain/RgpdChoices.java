package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(value = {"valid", "allFalse", "enabled"})
public class RgpdChoices {

    @Builder.Default
    private boolean homebotEnabled = false;
    @Builder.Default
    private boolean anonymousData = false;
    @Builder.Default
    private boolean devices = false;
    @Builder.Default
    private boolean audio = false;
    @Builder.Default
    private boolean video = false;
    @Builder.Default
    private boolean proactive = false;
    @Builder.Default
    private boolean learn = false;
    @Builder.Default
    private boolean data = false;

    @JsonCreator
    public RgpdChoices(@JsonProperty(value = "homebotEnabled", required = true) boolean homebotEnabled,
                       @JsonProperty(value = "anonymousData", required = true) boolean anonymousData,
                       @JsonProperty(value = "devices", required = true) boolean devices,
                       @JsonProperty(value = "audio", required = true) boolean audio,
                       @JsonProperty(value = "video", required = true) boolean video,
                       @JsonProperty(value = "proactive", required = true) boolean proactive,
                       @JsonProperty(value = "learn", required = true) boolean learn,
                       @JsonProperty(value = "data", required = true) boolean data) throws IllegalArgumentException {
        this.homebotEnabled = homebotEnabled;
        this.anonymousData = anonymousData;
        this.devices = devices;
        this.audio = audio;
        this.video = video;
        this.proactive = proactive;
        this.learn = learn;
        this.data = data;
        if(!this.isValid()){
            throw new IllegalArgumentException("Rgpd json invalid");
        }
    }

    public boolean isValid()  {
        if (this.homebotEnabled) {
            if (this.learn && !this.data) {
                return false;
            }
            return true;
        } else {
            return this.isAllFalse();
        }
    }
    public boolean isAllFalse() {
        return !(this.devices || this.audio  || this.video || this.proactive || this.learn || this.data);
    }

    public List<String> getEnabled(){
        List<String> result = new ArrayList<>();
        if(homebotEnabled){
            result.add("homebotEnabled");
            if(devices)
                result.add("devices");
            if(audio)
                result.add("audio");
            if(video)
                result.add("video");
            if(proactive)
                result.add("proactive");
            if(data){
                result.add("data");
                if(learn)
                    result.add("learn");
            }
        }
        if(anonymousData)
            result.add("anonymousData");
        return result;
    }

}
