package com.muvraline.authenticationserver.domain;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;

@Component
public class UserDetailsCustomSerializer extends JsonSerializer<UserDetailsCustom> {

	@Autowired
	private ObjectMapper mapper;

	@Override
	public void serialize(UserDetailsCustom source, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		serializers.defaultSerializeValue(asMap(source), gen);
	}
	
	public Map<String, Object> asMap(UserDetailsCustom source){
		Map<String, Object> result = new HashMap<>();
		result.put("accountId", source.getAccountId());
		if(source.getAgent() != null) {
			result.put("agent", source.getAgent());
		}
		result.put("roles", source.getRoles());
		result.put("email", source.getEmail());
		result.put("creationDate", source.getCreationDate());
		return result;
	}
	
	public String asJsonString(UserDetailsCustom source) throws JsonProcessingException{
		return mapper.writeValueAsString(asMap(source));
	}
	
	public JsonNode asJson(UserDetailsCustom source) throws JsonProcessingException{
		return mapper.readTree(mapper.writeValueAsString(asMap(source)));
	}


}

