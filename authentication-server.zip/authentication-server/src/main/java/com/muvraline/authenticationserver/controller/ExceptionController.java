package com.muvraline.authenticationserver.controller;

import com.fasterxml.jackson.databind.node.ObjectNode;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

//Ne pas catcher les exceptions dans les controlleurs mais ici
@ControllerAdvice
@Slf4j
public class ExceptionController {
    @ExceptionHandler(value = {ExpiredJwtException.class, JwtException.class, IllegalArgumentException.class,
            DisabledException.class, UsernameNotFoundException.class, BadCredentialsException.class})
    public ResponseEntity<ObjectNode> handleJwtException(Exception e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @ExceptionHandler(value = {HttpMessageNotReadableException.class})
    public ResponseEntity<ObjectNode> handleBadRequestException(Exception e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<ObjectNode> handleDefault(Exception e) {
        // should the body contain the exception message ?
        log.error("EXCEPTION : ");
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
    }
}
