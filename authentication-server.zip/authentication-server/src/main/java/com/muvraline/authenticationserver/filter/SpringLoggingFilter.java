package com.muvraline.authenticationserver.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.muvraline.authenticationserver.AuthenticationserverApplication;
import com.muvraline.authenticationserver.filter.event.Event;
import com.muvraline.authenticationserver.filter.event.RequestEvent;
import com.muvraline.authenticationserver.filter.event.RequestEvent.RequestEventBuilder;
import com.muvraline.authenticationserver.filter.event.ResponseEvent;
import com.muvraline.authenticationserver.filter.event.ResponseEvent.ResponseEventBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import static com.muvraline.authenticationserver.filter.LoggerUtils.*;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.muvraline.authenticationserver.filter.KafkaService;

@Slf4j
@Component
@PropertySource({ "classpath:configuration-${" + AuthenticationserverApplication.ENV_TYPE + ":docker}.properties" })
public class SpringLoggingFilter extends OncePerRequestFilter {

	@Value("${spring.logging.ignorePatterns:#{null}}")
	Optional<String> ignorePatterns;

	@Value("${spring.logging.includeHeaders:false}")
	boolean logHeaders;

	@Value("${kafka.enabled}")
	private boolean enabled;

	@Value(value = "Events")
	private String topicName;

	ObjectMapper mapper = new ObjectMapper();

	private static final String toIgnore = "actuator";

	@Autowired()
	private KafkaService kafkaService;

	@SuppressWarnings("rawtypes")
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		propagateHeaders(request, response);
		if (request.getRequestURI().contains(toIgnore)) {
			chain.doFilter(request, response);
			return;
		}
		final long startTime = System.currentTimeMillis();
		final SpringRequestWrapper wrappedRequest = new SpringRequestWrapper(request);
		// Log request
		RequestEvent requestEvent = EventUtils.buildRequestEvent(wrappedRequest);
		String requestId = request.getHeader(XREQUESTID);
		if(requestId != null)
			requestEvent.setRequestId(requestId);
		log(requestEvent);
		// End log request

		// do filter
 		final SpringResponseWrapper wrappedResponse = new SpringResponseWrapper(response);
		chain.doFilter(wrappedRequest, wrappedResponse);
		// end doFilter

		// Log response
		final long duration = System.currentTimeMillis() - startTime;

		ResponseEvent responseEvent = EventUtils.buildResponseEvent(wrappedResponse, requestEvent);
		log(responseEvent);
		// end log response
	}

	private void log(Event event) {
		kafkaService.sendMessageToKafka(event);
		log.info("Event sended to Kafka - {}", event.getClass().getName());
		log.info(event.toString());
	}
	
}
