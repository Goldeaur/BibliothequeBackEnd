package com.muvraline.authenticationserver.controller;


import com.fasterxml.jackson.databind.JsonNode;
import com.muvraline.authenticationserver.AccountDoesntExistsException;
import com.muvraline.authenticationserver.domain.*;
import com.muvraline.authenticationserver.message.EnableRequest;
import com.muvraline.authenticationserver.security.JwtTokenUtil;
import com.muvraline.authenticationserver.security.JwtUserDetailsService;
import com.muvraline.authenticationserver.service.CMService;
import com.muvraline.exception.CMException;
import com.muvraline.exception.MalformedRequestException;
import com.muvraline.exception.ResourceInConflictException;
import com.muvraline.exception.RoleNotAllowedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.net.URI;
import java.util.NoSuchElementException;

@RestController
@RequestMapping(value = "/sysadmin")
@CrossOrigin
@Slf4j
public class AdminSystemController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private CMService cmService;

    protected static final String TOKEN_PREFIX = "Bearer ";

    @GetMapping(value = "/accounts")
    public ResponseEntity<?> listAllAccountsLegacy(){
        return ResponseEntity.ok(userDetailsService.listAllUserAccounts());
    }

    @GetMapping(value = "/account")
    public ResponseEntity<?> listAllAccounts(){
        return ResponseEntity.ok(userDetailsService.listAllUserAccounts());
    }

    @GetMapping(value = "/account/{accountId}")
    public ResponseEntity<?> getAccountInfo(@PathVariable String accountId) {
        UserAccount account = null;
        try {
            account = userDetailsService.getUserAccount(accountId);
            return ResponseEntity.ok(account);
        }catch (AccountDoesntExistsException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/connect")
    public ResponseEntity<?> connectAsSysAdmin(@RequestBody AdminJwtRequest jwtRequest){
        try{
            UserDetails userDetails = userDetailsService.loadUserByUsernameAndAgent(jwtRequest.getAccountId(), jwtRequest.getAgent());
            final JwtResponse token = jwtTokenUtil.generateToken(userDetails);
            return ResponseEntity.ok(token);
        }catch(UsernameNotFoundException e){
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/account/register")
    public ResponseEntity<?> registerAccount(@RequestBody UserAccount userAccount) {
        try {
            if (userDetailsService.registerUserAccount(userAccount)) {
                String token = TOKEN_PREFIX + ((UserDetailsCustom) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getToken();
                cmService.createAccountCM(userAccount, token);
                return ResponseEntity.ok(null);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving new user account");
            }
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ControllerUtils.jsonErrorFromException(e));
        } catch (RoleNotAllowedException | MalformedRequestException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ControllerUtils.jsonErrorFromException(e));
        } catch (CMException e){
            log.error(e.getMessage());
            userDetailsService.deleteUserAccount(userAccount.getAccountId());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        } catch (Exception e) {
            log.error(e.getMessage());
            userDetailsService.deleteUserAccount(userAccount.getAccountId());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/account/associate")
    public ResponseEntity<?> associateAccount(@RequestBody UserAccount userAccount) {
        try {
            String token = TOKEN_PREFIX + ((UserDetailsCustom) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getToken();
            Agent agent = userAccount.getAgents().get(0);
            JsonNode homeConfiguration = cmService.getAccountCM(userAccount.getAccountId(), token);
            if(!homeConfiguration.get("agents").has(agent.getName())){
                if(agent.getRoles().contains(Role.ADMIN)){
                    cmService.createAdminAgentCM(userAccount.getAccountId(), agent.getName(), token);
                }else{
                    cmService.createGuestAgentCM(userAccount.getAccountId(), agent.getName(), token);
                }
            }
            if (userDetailsService.registerUserAccount(userAccount)) {
                return ResponseEntity.ok(null);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromString("Error saving new user account"));
            }
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ControllerUtils.jsonErrorFromException(e));
        } catch (RoleNotAllowedException | MalformedRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ControllerUtils.jsonErrorFromException(e));
        } catch (CMException e){
            return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(ControllerUtils.jsonErrorFromException(e));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/changepassword")
    public ResponseEntity<?> changePassword(@RequestBody ChangePassword changePassword){
        try{
            if(changePassword.getAgent() == null){
                userDetailsService.updateUserAccountPassword(changePassword);
            }else{
                userDetailsService.updateUserAccountAgentPassword(changePassword);
            }
            return ResponseEntity.ok(null);
        }catch (AccountDoesntExistsException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }catch(NoSuchElementException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Agent " + changePassword.getAgent() + " doesn't exists in account " + changePassword.getAccountId());
        }
    }

    @DeleteMapping(value = "/account/{accountId}")
    public ResponseEntity<?> deleteUserAccount(@PathVariable String accountId) {
        userDetailsService.deleteUserAccount(accountId);
        try {
            String token = TOKEN_PREFIX + ((UserDetailsCustom) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getToken();
            cmService.deleteAccountCM(accountId, token);
        } catch (CMException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        }
        log.info("deleted account : {}", accountId);
        return ResponseEntity.ok(null);
    }

    @PostMapping(value = "/account/{accountId}/disable")
    public ResponseEntity<?> disableUser(@PathVariable String accountId) {
        try {
            userDetailsService.disableUserAccount(accountId);
            return ResponseEntity.ok(String.format("account: %s disabled", accountId));
        } catch (AccountDoesntExistsException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/account/{accountId}/enable")
    public ResponseEntity<?> enableUser(@PathVariable String accountId) {
        try {
            userDetailsService.enableUserAccount(accountId);
            return ResponseEntity.ok(String.format("account: %s enabled", accountId));
        } catch (AccountDoesntExistsException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PatchMapping(value = "/account/{accountId}")
    public ResponseEntity<?> enable(@PathVariable String accountId, @RequestBody EnableRequest request) {
        try {
            if(request.isEnable()){
                userDetailsService.enableUserAccount(accountId);
            }else if(!request.isEnable()){
                userDetailsService.disableUserAccount(accountId);
            }else{
                throw new MalformedRequestException("Missing enable information");
            }
            return ResponseEntity.ok(String.format("account: %s enabled", accountId));
        } catch (AccountDoesntExistsException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ControllerUtils.jsonErrorFromException(e));
        } catch (MalformedRequestException e){
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ControllerUtils.jsonErrorFromException(e));
        }
    }


}
