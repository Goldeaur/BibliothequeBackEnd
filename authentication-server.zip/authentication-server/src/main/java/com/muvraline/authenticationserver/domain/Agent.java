package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Builder
@ToString
public class Agent {

    @JsonProperty(required = true)
    private String name;
    @JsonProperty(required = true, access = JsonProperty.Access.WRITE_ONLY)
    private String password;
    @Builder.Default
    @JsonProperty(required = true)
    private List<Role> roles = Arrays.asList(Role.USER);

    private LocalDateTime lastConnection;

    //listConnexion ???
    @JsonCreator
    public Agent(@JsonProperty(value = "name", required = true) String name, @JsonProperty(value = "password",
            required = true) String password, @JsonProperty(value = "roles", required = true) List<Role> roles,
                 @JsonProperty(value = "lastConnection") LocalDateTime lastConnection) {
        this.name = name;
        this.password = password;
        this.roles = roles;
        this.lastConnection = lastConnection;
    }

}
