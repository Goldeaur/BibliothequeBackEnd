package com.muvraline.authenticationserver;

public class AccountDoesntExistsException extends Exception {
    public AccountDoesntExistsException(String s) {
        super(s);
    }
}
