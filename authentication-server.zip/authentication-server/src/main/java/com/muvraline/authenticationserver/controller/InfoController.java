package com.muvraline.authenticationserver.controller;

import com.muvraline.authenticationserver.domain.Country;
import com.muvraline.authenticationserver.domain.OpCo;
import com.muvraline.authenticationserver.security.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/info")
@CrossOrigin
@Slf4j
public class InfoController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @GetMapping(value = "/jwk")
    public ResponseEntity<?> jwk() {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(jwtTokenUtil.getJwk());
    }

    @GetMapping(value = "/opCos")
    public ResponseEntity<?> opCos() {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(OpCo.values());
    }

    @GetMapping(value = "/countries")
    public ResponseEntity<?> countries() {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(Country.values());
    }


}
