package com.muvraline.authenticationserver.message;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class EnableRequest {

    @JsonAlias(value = {"enable"})
    private boolean enable;
}
