package com.muvraline.authenticationserver.oauth2.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class AuthorizationRequest {

    private String clientId;
    private String state;
    private String redirectUri;

}
