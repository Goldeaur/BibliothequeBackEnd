package com.muvraline.authenticationserver.domain;


import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public enum OpCo {

    SFR("SFR"),
    MEO("MEO"),
    ORANGE("ORANGE"),
    BOUYGUES_TELECOM("BOUYGUES_TELECOM"),
    CIEL_TELECOM("CIEL_TELECOM"),
    FREE("FREE"),
    LA_POSTE("LA_POSTE"),
    CEGETEL("CEGETEL");

    private String name;

    OpCo(String name) {
        this.name = name;
    }

    @Override
    @JsonValue
    public String toString() {
        return name;
    }

    private static final Map<String, OpCo> nameIndex = new HashMap<String, OpCo>(OpCo.values().length);

    static {
        Arrays.asList(OpCo.values()).stream().forEach(opCo -> nameIndex.put(opCo.toString(), opCo));
    }

    public static OpCo lookupByName(String name) {
        return nameIndex.get(name);
    }


}
