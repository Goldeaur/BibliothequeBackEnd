package com.muvraline.authenticationserver.security;

import com.muvraline.authenticationserver.domain.Role;
import com.muvraline.authenticationserver.domain.SupportAccount;
import com.muvraline.exception.ResourceInConflictException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import static com.muvraline.authenticationserver.AuthenticationserverApplication.ENV_TYPE;

@Slf4j
@Component
public class ApplicationListenerImpl implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private JwtUserDetailsService detailService;

    @Autowired
    private ConfigurableApplicationContext ctx;


    @Value("${security.username}")
    private String username;
    @Value("${security.password}")
    private String password;

    @Value("${admin.email}")
    private String adminEmail;
    @Value("${admin.password}")
    private String adminPassword;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        SupportAccount userAccount1 = SupportAccount.builder().email(adminEmail).password(adminPassword).role(Role.SYS_ADMIN).enabled(true).build();
        SupportAccount userAccount2 = SupportAccount.builder().email(username).password(password).role(Role.BASIC_AUTH).enabled(true).build();
        SupportAccount userAccount3 = SupportAccount.builder().email("admin_support@muvraline.fr").password("admin").role(Role.SUPPORT_ADMIN).enabled(true).build();
        try {
            detailService.registerSupportAccountNoCheck(userAccount1);
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            ctx.close();
        }
        try {
            detailService.registerSupportAccountNoCheck(userAccount2);
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            ctx.close();
        }

        try {
            detailService.registerSupportAccountNoCheck(userAccount3);
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            ctx.close();
        }

/*		try {
			detailService.registerSupportAccountNoCheck(userAccount1);
		} catch (ResourceInConflictException e) {
			log.error(e.getMessage());
		}catch(Exception e) {
			e.printStackTrace();
			ctx.close();
		}
		try {
			detailService.registerSupportAccountNoCheck(userAccount2);
		} catch (ResourceInConflictException e) {
			log.error(e.getMessage());
		}catch(Exception e) {
			e.printStackTrace();
			ctx.close();
		}*/
    }

}
