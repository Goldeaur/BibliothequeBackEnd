package com.muvraline.authenticationserver.security;

import com.muvraline.authenticationserver.AccountDoesntExistsException;
import com.muvraline.authenticationserver.domain.*;
import com.muvraline.authenticationserver.domain.repository.UserAccountRepository;
import com.muvraline.authenticationserver.domain.repository.SupportAccountRepository;
import com.muvraline.exception.MalformedRequestException;
import com.muvraline.exception.ResourceInConflictException;
import com.muvraline.exception.ResourceNotFoundException;
import com.muvraline.exception.RoleNotAllowedException;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import static com.muvraline.authenticationserver.security.JwtTokenUtil.ADMIN;

@Service
@Slf4j
@SuppressWarnings({"rawtypes", "unchecked"})
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Autowired
    private SupportAccountRepository supportAccountRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenUtil tokenUtil;

    @Override
    public UserDetails loadUserByUsername(final String login) throws UsernameNotFoundException {
        UserAccount userAccount = userAccountRepository.findByAccountId(login);
        if (userAccount == null) {
            //log.error("User {} not found", login);
            throw new UsernameNotFoundException(login);
        }
        User user = new User(userAccount);
        return new UserDetailsCustom(user, user.getRoles());
    }

    public UserDetailsCustom loadSupportByEmail(final String email) throws UsernameNotFoundException {
        SupportAccount supportAccount = supportAccountRepository.findByEmail(email);
        if (supportAccount == null) {
            throw new UsernameNotFoundException(email);
        }
        User user = new User(supportAccount);
        return new UserDetailsCustom(user, user.getRoles());
    }

    public UserDetailsCustom loadPartnerUserByRefreshToken(final String refreshToken) throws UsernameNotFoundException {
        User user = tokenUtil.getUserFromRefreshToken(refreshToken);
        return loadUserByUsernameAndAgent(user.getAccountId(), null);
    }

    public UserDetailsCustom loadUserByRefreshToken(final String refreshToken) throws UsernameNotFoundException {
        User user = tokenUtil.getUserFromRefreshToken(refreshToken);
        if (user.getAccountId() != null) {
            return loadUserByUsernameAndAgent(user.getAccountId(), user.getAgent());
        } else {
            return loadSupportByEmail(user.getEmail());
        }
    }

    public UserDetailsCustom loadUserByUsernameAndAgent(final String login, final String agentName)
            throws UsernameNotFoundException {
        UserAccount userAccount = userAccountRepository.findByAccountId(login);
        if (userAccount == null) {
            userAccount = userAccountRepository.findByEmail(login);
            //log.error("User account {} not found", login);
        }
        if (userAccount == null) {
            SupportAccount supportAccount = supportAccountRepository.findByEmail(login);
            if (supportAccount == null) {
                log.error("UserAccount or Support account " + login + " not found");
                throw new UsernameNotFoundException("UserAccount or Support account " + login + " not found");
            }
            User user = new User(supportAccount);
            return new UserDetailsCustom(user, user.getRoles());
        }
        if (agentName == null) {
            User user = new User(userAccount);
            return new UserDetailsCustom(user, user.getRoles());
        }
        try {
            User user = new User(userAccount, agentName);
            return new UserDetailsCustom(user, user.getRoles());
        } catch (NoSuchElementException e) {
            throw new UsernameNotFoundException("Agent " + agentName + " not found in account " + login);
        }
    }


    public UserDetails loadByUser(User user) {
        UserDetails details = loadUserByUsernameAndAgent(user.getAccountId(), user.getAgent());
        user.setEnabled(details.isEnabled());
        return new UserDetailsCustom(user, details.getAuthorities());
    }

    private void validateUserAccountInfo(UserAccount userAccount) throws MalformedRequestException, RoleNotAllowedException {
        if (userAccount.getOpCo() == null) {
            throw new MalformedRequestException("opCo field is required");
        }
        if (userAccount.getCountry() == null) {
            throw new MalformedRequestException("country field is required");
        }
        if (userAccount.getAgents().size() != 1) {
            throw new MalformedRequestException("Can only create an account with 1 agent");
        }
        if (userAccount.getPassword() == null || userAccount.getPassword().isEmpty()) {
            throw new MalformedRequestException("password field is required");
        }
        if (userAccount.getAccountId() == null || userAccount.getAccountId().isEmpty()) {
            throw new MalformedRequestException("accountId field is required");
        }
        validateRoles(userAccount);
    }

    public boolean registerUserAccount(UserAccount userAccount) throws MalformedRequestException, ResourceInConflictException, RoleNotAllowedException {
        validateUserAccountInfo(userAccount);
        userAccount.setEnabled(true);
        return setupAndSaveUserAccount(userAccount);
    }

    public boolean registerSupportAccount(SupportAccount supportAccount) throws RoleNotAllowedException, ResourceInConflictException, MalformedRequestException {
        validateSupportAccountInfo(supportAccount);
        return setupAndSaveSupportAccount(supportAccount);
    }

    private void validateSupportAccountInfo(SupportAccount supportAccount) throws RoleNotAllowedException, MalformedRequestException {
        if (!Role.canBeCreatedBy(Role.SUPPORT_ADMIN, supportAccount.getRole())) {
            throw new RoleNotAllowedException("Can't create a support account with this role : " + supportAccount.getRole().name());
        }
        if (supportAccount.getOpCo() == null) {
            throw new MalformedRequestException("opCo field is required");
        }
        if (supportAccount.getCountry() == null) {
            throw new MalformedRequestException("country field is required");
        }
        if (supportAccount.getEmail() == null || supportAccount.getEmail().isEmpty()) {
            throw new MalformedRequestException("email field is required");
        }
        if (supportAccount.getPassword() == null || supportAccount.getPassword().isEmpty()) {
            throw new MalformedRequestException("password field is required");
        }
    }

    public void validateRoles(UserAccount userAccount) throws RoleNotAllowedException, MalformedRequestException {
        if (!Role.canBeCreatedBy(Role.SYS_ADMIN, userAccount.getRole())) {
            throw new RoleNotAllowedException("Can't create a user account with this role : " + userAccount.getRole().name());
        }
        for (Agent agent : userAccount.getAgents()) {
            if (agent.getName() == null || agent.getName().isEmpty()) {
                throw new MalformedRequestException("name field is required for agent");
            }
            if (agent.getPassword() == null || agent.getPassword().isEmpty()) {
                throw new MalformedRequestException("password field is required for agent");
            }
            validateAgentRoles(agent.getRoles());
        }
    }

    protected boolean registerSupportAccountNoCheck(SupportAccount supportAccount) throws ResourceInConflictException {
        return setupAndSaveSupportAccount(supportAccount);
    }

    public void addAgent(String accountId, Agent agent) throws RoleNotAllowedException, ResourceInConflictException, ResourceNotFoundException {
        UserAccount userAccount = userAccountRepository.findByAccountId(accountId);
        if (userAccount == null)
            throw new ResourceNotFoundException("Account with id " + accountId + " not found");
        validateAgentRoles(agent.getRoles());
        agent.setPassword(passwordEncoder.encode(agent.getPassword()));
        userAccount.addAgent(agent);
        userAccountRepository.save(userAccount);
    }

    public void setRgpdChoices(String accountId, RgpdChoices choices) throws ResourceNotFoundException {
        UserAccount userAccount = userAccountRepository.findByAccountId(accountId);
        if (userAccount == null)
            throw new ResourceNotFoundException("Account with id " + accountId + " not found");
        userAccount.setRgpdChoices(choices);
        userAccountRepository.save(userAccount);
    }

    public void deleteAgent(String accountId, String agentname) throws ResourceNotFoundException {
        UserAccount userAccount = userAccountRepository.findByAccountId(accountId);
        if (userAccount == null)
            throw new ResourceNotFoundException("Account with id " + accountId + " not found");
        userAccount.removeAgent(agentname);
        userAccountRepository.save(userAccount);
    }

    public void deleteUserAccount(String accountId) {
        userAccountRepository.deleteByAccountId(accountId);
    }

    public void deleteSupportAccount(String email) {
        SupportAccount account = supportAccountRepository.findByEmail(email);
        if (account != null && isRealSupport(account)) {
            supportAccountRepository.deleteById(email);
        }
    }

    public List<Agent> getAgents(String accountId) throws Exception {
        UserAccount userAccount = userAccountRepository.findByAccountId(accountId);
        if (userAccount == null)
            throw new ResourceNotFoundException("Account with id " + accountId + " not found");
        return userAccount.getAgents();
    }

    public void validateAgentRoles(List<Role> roles) throws RoleNotAllowedException {
        if (roles.isEmpty()) {
            throw new RoleNotAllowedException("Missing role for agent");
        }
        List<Role> invalidRoles = roles.stream().filter(role -> !Role.canBeCreatedBy(Role.SYS_ADMIN, role)).collect(Collectors.toList());
        if (!invalidRoles.isEmpty()) {
            throw new RoleNotAllowedException("Can't create an agent with these roles : " + invalidRoles);
        }
    }

    public List<AccountMessage> listAllUserAccounts() {
        return userAccountRepository.findAll().stream().map(account ->{
         return  AccountMessage.builder().accountId(account.getAccountId()).enabled(account.isEnabled()).build();
        }).collect(Collectors.toList());
    }

    public List<String> listAllSupportAccounts() {
        return supportAccountRepository.findAll().stream().filter(account -> isRealSupport(account)).map(account -> account.getEmail()).collect(Collectors.toList());
    }

    private boolean isRealSupport(SupportAccount account) {
        return account.getRole() != Role.SYS_ADMIN && account.getRole() != Role.SUPPORT_ADMIN && account.getRole() != Role.BASIC_AUTH;
    }

    public void updateUserAccountPassword(ChangePassword changePassword) throws AccountDoesntExistsException {
        UserAccount account = userAccountRepository.findByAccountId(changePassword.getAccountId());
        if (account == null) {
            throw new AccountDoesntExistsException("User account " + changePassword.getAccountId() + " not found");
        }
        account.setPassword(passwordEncoder.encode(changePassword.getPassword()));
        userAccountRepository.save(account);
    }

    public void updateUserAccountAgentPassword(ChangePassword changePassword) throws AccountDoesntExistsException {
        UserAccount account = userAccountRepository.findByAccountId(changePassword.getAccountId());
        if (account == null) {
            throw new AccountDoesntExistsException("User account " + changePassword.getAccountId() + " not found");
        }
        Agent agent = account.getAgent(changePassword.getAgent());
        agent.setPassword(passwordEncoder.encode(changePassword.getPassword()));
        userAccountRepository.save(account);
    }

    public UserAccount getUserAccount(String accountId) throws AccountDoesntExistsException {
        UserAccount account = userAccountRepository.findByAccountId(accountId);
        if (account == null) {
            throw new AccountDoesntExistsException("User account " + accountId + " not found");
        }
        return account;
    }

    public SupportAccount getSupportAccount(String email) throws AccountDoesntExistsException {
        SupportAccount account = supportAccountRepository.findByEmail(email);
        if (account == null) {
            throw new AccountDoesntExistsException("Support account " + email + " not found");
        }
        return account;
    }

    private boolean setupAndSaveUserAccount(UserAccount userAccount) throws ResourceInConflictException {
        if (userAccountRepository.findByEmail(userAccount.getEmail()) != null)
            throw new ResourceInConflictException("User account with email " + userAccount.getEmail() + " already exists");

        if (userAccountRepository.findByAccountId(userAccount.getAccountId()) != null)
            throw new ResourceInConflictException("User account with id " + userAccount.getAccountId() + " already exists");

        userAccount.setCreationDate(LocalDateTime.now());
        userAccount.setPassword(passwordEncoder.encode(userAccount.getPassword()));
        for (Agent agent : userAccount.getAgents()) {
            String encoded = passwordEncoder.encode(agent.getPassword());
            agent.setPassword(encoded);
        }
        return userAccountRepository.save(userAccount) != null;
    }

    private boolean setupAndSaveSupportAccount(SupportAccount supportAccount) throws ResourceInConflictException {
        if (supportAccountRepository.findByEmail(supportAccount.getEmail()) != null) {
            throw new ResourceInConflictException("Support account " + supportAccount.getEmail() + " already exists");
        }
        supportAccount.setCreationDate(LocalDateTime.now());
        supportAccount.setPassword(passwordEncoder.encode(supportAccount.getPassword()));
        return supportAccountRepository.save(supportAccount) != null;
    }

    public void disableUserAccount(String accountId) throws AccountDoesntExistsException {
        setEnableUserAccount(accountId, false);
    }

    public void setEnableUserAccount(String accountId, boolean enabled) throws AccountDoesntExistsException {
        UserAccount account = userAccountRepository.findByAccountId(accountId);
        if (account == null) {
            throw new AccountDoesntExistsException("User account " + accountId + " not found");
        }
        account.setEnabled(enabled);
        userAccountRepository.save(account);
    }

    public void enableUserAccount(String accountId) throws AccountDoesntExistsException {
        setEnableUserAccount(accountId, true);
    }

    public void setConnectionDate(UserDetailsCustom userDetailsCustom) {

        if (userDetailsCustom.isUser()) {
            userAccountRepository.updateLastConnection(userDetailsCustom.getEmail(), UserAccount.class);
        } else {
            supportAccountRepository.updateLastConnection(userDetailsCustom.getEmail(), SupportAccount.class);
        }
    }

}
@Builder
@Getter
@Setter
class AccountMessage
{
    private String accountId;
    private boolean enabled;
}
