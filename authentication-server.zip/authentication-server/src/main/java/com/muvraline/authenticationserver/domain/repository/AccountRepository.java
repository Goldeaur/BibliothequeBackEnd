package com.muvraline.authenticationserver.domain.repository;

public interface  AccountRepository {

    public void updateLastConnection(String id, Class clazz);

}
