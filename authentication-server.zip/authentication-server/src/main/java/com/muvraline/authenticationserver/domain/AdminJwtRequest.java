package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@Builder
public class AdminJwtRequest {

    private String accountId;
    private String agent;

    @JsonCreator
    public AdminJwtRequest(@JsonProperty(value = "accountId", required = true) String accountId, @JsonProperty(value = "agent") String agent) {
        this.accountId = accountId;
        this.agent = agent;
    }
}
