package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum Role implements GrantedAuthority {

    ADMIN("ADMIN"),
    USER("USER"),
    SYS_ADMIN("SYS_ADMIN"),
    SUPPORT_ADMIN("SUPPORT_ADMIN"),
    SUPPORT_1("SUPPORT_1"),
    SUPPORT_2("SUPPORT_2"),
    SUPPORT_3("SUPPORT_3"),
    BASIC_AUTH("BASIC_AUTH");

    private String name;

    Role(String name) {
        this.name = name;
    }

    @Override
    @JsonValue
    public String toString() {
        return name;
    }

    private static final Map<String, Role> nameIndex = new HashMap<String, Role>(Role.values().length);

    static {
        Arrays.asList(Role.values()).stream().forEach(role -> nameIndex.put(role.toString(), role));
    }

    public static Role lookupByName(String name) {
        return nameIndex.get(name);
    }

    public static boolean canBeCreatedBy(Role role, Role roleToCreate){
        if(role.equals(SYS_ADMIN)){
            return userRoles.contains(roleToCreate);
        }
        if(role.equals(SUPPORT_ADMIN)){
            return supportRoles.contains(roleToCreate);
        }
        return false;
    }

    private static final List<Role> userRoles = Arrays.asList(ADMIN, USER);
    private static final List<Role> supportRoles = Arrays.asList(SUPPORT_1, SUPPORT_2, SUPPORT_3);

    @Override
    public String getAuthority() {
        return this.name;
    }

    public static List<Role> getUserRoles() {
        return userRoles;
    }
}
