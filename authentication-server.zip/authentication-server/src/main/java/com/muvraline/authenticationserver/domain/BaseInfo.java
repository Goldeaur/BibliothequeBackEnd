package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;
import java.util.ArrayList;

@Getter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
abstract class BaseInfo {

    @Id
    @JsonProperty(required = true)
    protected String email;

    @Setter
    @JsonProperty(required = true, access = JsonProperty.Access.WRITE_ONLY)
    protected String password;

    @Setter
    protected LocalDateTime creationDate;

    @Setter
    @Builder.Default
    protected boolean enabled = true;

    @Setter
    protected LocalDateTime lastConnection;

}