package com.muvraline.authenticationserver.controller;

import com.muvraline.authenticationserver.domain.*;
import com.muvraline.authenticationserver.security.JwtUserDetailsService;
import com.muvraline.authenticationserver.service.CMService;
import com.muvraline.exception.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/user")
@CrossOrigin
@Slf4j
public class UserController {

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private UserDetailsCustomSerializer userDetailSerializer;

    private static final String AGENT_URI = "/agent/";

    @Autowired
    private CMService cmService;

    @GetMapping(value = "/me")
    public ResponseEntity<?> me(@AuthenticationPrincipal Authentication auth) throws Exception {
        UserDetailsCustom custom = (UserDetailsCustom) auth.getPrincipal();
        return ResponseEntity.ok(userDetailSerializer.asJson(custom));
    }

    @GetMapping(value = "/info")
    public ResponseEntity<?> info(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @AuthenticationPrincipal Authentication auth) throws Exception {
        String accountId;
        try {
            accountId = getAccountId(accountIdHeader, auth);
        } catch (HeaderMissingException e) {
            return ResponseEntity.badRequest().body(ControllerUtils.jsonErrorFromException(e));
        }
        UserAccount account = userDetailsService.getUserAccount(accountId);
        return ResponseEntity.ok(account);
    }

    @PostMapping(value = "/rgpd")
    public ResponseEntity<?> setRgpdChoices(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @RequestBody RgpdChoices choices, @AuthenticationPrincipal Authentication auth) {
        String accountId;
        try {
            accountId = getAccountId(accountIdHeader, auth);
        } catch (HeaderMissingException e) {
            return ResponseEntity.badRequest().body(ControllerUtils.jsonErrorFromException(e));
        }
        return setRgpdChoices(choices, accountId);
    }

    private ResponseEntity<?> setRgpdChoices(RgpdChoices choices, String accountId) {
        try{
            userDetailsService.setRgpdChoices(accountId, choices);
            return ResponseEntity.ok(null);
        } catch (ResourceNotFoundException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/agent")
    public ResponseEntity<?> addAgent(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @RequestBody Agent agent, @AuthenticationPrincipal Authentication auth) {
        String accountId;
        try {
            accountId = getAccountId(accountIdHeader, auth);
        } catch (HeaderMissingException e) {
            return ResponseEntity.badRequest().body(ControllerUtils.jsonErrorFromException(e));
        }
        return addAgentFromAccountId(agent, accountId);
    }

    @DeleteMapping(value = "/agent/{name}")
    public ResponseEntity<?> deleteAgent(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @PathVariable String name, @AuthenticationPrincipal Authentication auth) {
        String accountId;
        try {
            accountId = getAccountId(accountIdHeader, auth);
        } catch (HeaderMissingException e) {
            return ResponseEntity.badRequest().body(ControllerUtils.jsonErrorFromException(e));
        }
        try {
            userDetailsService.deleteAgent(accountId, name);
            cmService.deleteAgentCM(accountId, name);
            return ResponseEntity.ok(null);
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @GetMapping(value = "/agents")
    public ResponseEntity<?> getAllAgentsLegacy(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @AuthenticationPrincipal Authentication auth) {
        return getAllAgentsImpl(accountIdHeader, auth);
    }

    @GetMapping(value = "/agent")
    public ResponseEntity<?> getAllAgents(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @AuthenticationPrincipal Authentication auth) {
        return getAllAgentsImpl(accountIdHeader, auth);
    }

    private ResponseEntity<?> getAllAgentsImpl(@RequestHeader(name = "accountId", required = false) String accountIdHeader, @AuthenticationPrincipal Authentication auth) {
        String accountId;
        try {
            accountId = getAccountId(accountIdHeader, auth);
        } catch (HeaderMissingException e) {
            return ResponseEntity.badRequest().body(ControllerUtils.jsonErrorFromException(e));
        }
        try {
            return ResponseEntity.ok(userDetailsService.getAgents(accountId));
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ControllerUtils.jsonErrorFromException(e));
        }
    }


    private String getAccountId(String accountIdHeader, Authentication auth) throws HeaderMissingException {
        String accountId;
        if(auth.getAuthorities().contains(Role.SYS_ADMIN)){
            if(accountIdHeader == null){
                throw new HeaderMissingException("Missing accountId header");
            }
            accountId = accountIdHeader;
        }else{
            accountId = auth.getName();
        }
        return accountId;
    }

    private ResponseEntity<?> addAgentFromAccountId(Agent agent, String accountId) {
        try {
            userDetailsService.addAgent(accountId, agent);
            UserDetailsCustom details = (UserDetailsCustom) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String token = AdminSystemController.TOKEN_PREFIX + details.getToken();
            if (agent.getRoles().contains(Role.ADMIN)) {
                cmService.createAdminAgentCM(accountId, agent.getName(), token);
            } else {
                cmService.createGuestAgentCM(accountId, agent.getName(), token);
            }
        } catch (RoleNotAllowedException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ControllerUtils.jsonErrorFromException(e));
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ControllerUtils.jsonErrorFromException(e));
        }catch (ResourceNotFoundException e){
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        } catch (CMException e) {
            log.error(e.getMessage());
            try {
                userDetailsService.deleteAgent(accountId, agent.getName());
            } catch (ResourceNotFoundException ex) {
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        }
        return ResponseEntity.ok(null);
    }
}
