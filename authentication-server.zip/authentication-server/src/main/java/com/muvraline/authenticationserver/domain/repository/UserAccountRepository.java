package com.muvraline.authenticationserver.domain.repository;

import com.muvraline.authenticationserver.domain.SupportAccount;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.muvraline.authenticationserver.domain.UserAccount;

public interface UserAccountRepository extends MongoRepository<UserAccount, String>, AccountRepository  {

	public UserAccount findByEmail(final String email);

	public UserAccount findByAccountId(final String accountId);

	public void deleteByAccountId(final String accountId);

}
