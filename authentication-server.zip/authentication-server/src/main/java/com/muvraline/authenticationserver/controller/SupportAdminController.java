package com.muvraline.authenticationserver.controller;

import com.muvraline.authenticationserver.AccountDoesntExistsException;
import com.muvraline.authenticationserver.domain.SupportAccount;
import com.muvraline.authenticationserver.security.JwtUserDetailsService;
import com.muvraline.exception.MalformedRequestException;
import com.muvraline.exception.ResourceInConflictException;
import com.muvraline.exception.RoleNotAllowedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/supportadmin")
@CrossOrigin
@Slf4j
public class SupportAdminController {

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @GetMapping(value = "/accounts")
    public ResponseEntity<?> listAllAccounts(){
        return ResponseEntity.ok(userDetailsService.listAllSupportAccounts());
    }

    @GetMapping(value = "/account/{email}")
    public ResponseEntity<?> getAccount(@PathVariable String email){
        try {
            return ResponseEntity.ok(userDetailsService.getSupportAccount(email));
        } catch (AccountDoesntExistsException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @PostMapping(value = "/account/register")
    public ResponseEntity<?> registerAccount(@RequestBody SupportAccount account) {
        try {
            if (userDetailsService.registerSupportAccount(account)) {
                return ResponseEntity.ok(null);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromString("Error saving new support account"));
            }
        } catch (RoleNotAllowedException | MalformedRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ControllerUtils.jsonErrorFromException(e));
        } catch (ResourceInConflictException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ControllerUtils.jsonErrorFromException(e));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ControllerUtils.jsonErrorFromException(e));
        }
    }

    @DeleteMapping(value = "/account/{email}")
    public ResponseEntity<?> deleteSupportAccount(@PathVariable String email) {
        userDetailsService.deleteSupportAccount(email);
        return ResponseEntity.ok(null);
    }

}
