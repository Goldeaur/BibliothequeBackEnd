package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public enum Country {

    FRANCE("FRANCE"),
    PORTUGAL("PORTUGAL"),
    KAZAKHSTAN("KAZAKHSTAN"),
    KIRGHIZISTAN("KIRGHIZISTAN"),
    TURKMENISTAN("TURKMENISTAN"),
    DOMINICAN_REPUBLIC("DOMINICAN_REPUBLIC"),
    OUZBEKISTAN("OUZBEKISTAN"),
    TADJIKISTAN("TADJIKISTAN"),
    BOUHTAN("BOUHTAN"),
    AFGHANISTAN("AFGHANISTAN"),
    AZERBAIDJAN("AZERBAIDJAN");

    private String name;

    Country(String name) {
        this.name = name;
    }

    @Override
    @JsonValue
    public String toString() {
        return name;
    }

    private static final Map<String, Country> nameIndex = new HashMap<String, Country>(Country.values().length);

    static {
        Arrays.asList(Country.values()).stream().forEach(country -> nameIndex.put(country.toString(), country));
    }

    public static Country lookupByName(String name) {
        return nameIndex.get(name);
    }

}
