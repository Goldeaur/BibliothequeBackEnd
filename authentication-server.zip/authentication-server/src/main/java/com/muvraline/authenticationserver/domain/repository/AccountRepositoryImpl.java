package com.muvraline.authenticationserver.domain.repository;

import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.time.LocalDateTime;

public class AccountRepositoryImpl implements AccountRepository {

    @Autowired
    private MongoTemplate mongo;

    @Override
    public void updateLastConnection(String id, Class clazz) {

        Query select = Query.query(Criteria.where("_id").is(id));
        Update update = new Update();
        update.set("lastConnection", LocalDateTime.now());
        mongo.updateFirst(select, update, clazz);

    }
}