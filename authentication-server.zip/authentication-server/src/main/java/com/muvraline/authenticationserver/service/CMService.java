package com.muvraline.authenticationserver.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.muvraline.authenticationserver.domain.UserAccount;
import com.muvraline.exception.CMException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
@Slf4j
public class CMService {



    @Autowired
    private RestTemplate restTemplate;

    @Value("${cm.homeconfiguration.url}")
    private String homeconfigurationUrl;

    @Value("${security.username}")
    private static String basicAuthUsername;

    private static final String AGENT_URI = "/agent/";

    private static final String ROLE_URI = "/role/";

    private static final String GUEST = "guest";

    private static final String ADMIN = "admin";


    private static final int MAX_RETRY_CM = 3;

    public void createAccountCM(UserAccount userAccount, String token) throws CMException {
        try{
            String url = homeconfigurationUrl + userAccount.getAccountId() + "/default/"+ userAccount.getAgents().get(0).getName();
            RequestEntity<Void> request = RequestEntity.post(URI.create(url)).header("Authorization", token).build();
            restTemplate.exchange(request, JsonNode.class);
        }catch(RestClientException e){
            log.error("error creating account in CM {}", e.getMessage());
            throw new CMException("Error contacting CM : " + e.getMessage());
        }
    }

    public void createAdminAgentCM(String accountId, String agentName, String token) throws CMException {
        try{
            String url = homeconfigurationUrl + accountId + AGENT_URI + agentName + ROLE_URI + ADMIN;
            RequestEntity<Void> request = RequestEntity.post(URI.create(url)).header("Authorization", token).build();
            restTemplate.exchange(request, JsonNode.class);
        }catch(RestClientException e){
            log.error("error creating admin agent in CM {}", e.getMessage());
            throw new CMException("Error contacting CM : " + e.getMessage());
        }
    }

    public void createGuestAgentCM(String accountId, String agentName, String token) throws CMException {
        try{
            String url = homeconfigurationUrl + accountId + AGENT_URI + agentName + ROLE_URI + GUEST;
            RequestEntity<Void> request = RequestEntity.post(URI.create(url)).header("Authorization", token).build();
            restTemplate.exchange(request, JsonNode.class);
        }catch(RestClientException e){
            log.error("error creating guest agent in CM {}", e.getMessage());
            throw new CMException("Error contacting CM : " + e.getMessage());
        }
    }

    public JsonNode getAccountCM(String accountId, String token) throws CMException{
        try{
            String url = homeconfigurationUrl + accountId;
            RequestEntity<Void> request = RequestEntity.get(URI.create(url)).header("Authorization", token).build();
            return restTemplate.exchange(request, JsonNode.class).getBody();
        }catch(RestClientException e){
            log.error("error getting account from CM {}", e.getMessage());
            throw new CMException("Error contacting CM : " + e.getMessage());
        }
    }

    public void deleteAccountCM(String accountId, String token) throws CMException{
        try{
            String url = homeconfigurationUrl + accountId;
            RequestEntity<Void> request = RequestEntity.delete(URI.create(url)).header("Authorization", token).build();
            restTemplate.exchange(request, JsonNode.class);
        }catch(RestClientException e){
            log.error("error deleting account from CM {}", e.getMessage());
            throw new CMException("Error contacting CM : " + e.getMessage());
        }
    }

    public void deleteAgentCM(String accountId, String agentName){
        restTemplate.delete(homeconfigurationUrl + accountId + AGENT_URI + agentName);
    }

}
