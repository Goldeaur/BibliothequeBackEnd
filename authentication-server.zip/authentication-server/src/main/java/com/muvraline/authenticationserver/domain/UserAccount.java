package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.muvraline.exception.ResourceInConflictException;
import com.muvraline.exception.ResourceNotFoundException;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@ToString
@Document("userAccount")
public class UserAccount extends UserAccountNoAgent {

    @Builder.Default
    protected List<Agent> agents = new ArrayList<>();

    @JsonCreator
    public UserAccount(@JsonProperty(value = "accountId", required = true) String accountId,
                       @JsonProperty(value = "password", required = true) String password,
                       @JsonProperty(value = "email", required = true) String email,
                       @JsonProperty(value = "country", required = true) Country country,
                       @JsonProperty(value = "opCo", required = true) OpCo opCo,
                       @JsonProperty(value = "agents") List<Agent> agents,
                       @JsonProperty(value = "enabled", defaultValue = "true") boolean enabled) {
        this.accountId = accountId;
        this.password = password;
        this.email = email;
        this.country = country;
        this.opCo = opCo;
        this.agents = agents;
        this.enabled = enabled;
        this.role = Role.ADMIN;
    }


    public void addAgent(Agent agent) throws ResourceInConflictException {
        if (hasAgent(agent.getName())) {
            throw new ResourceInConflictException("Agent " + agent.getName() + " already in account");
        }
        agents.add(agent);
    }

    public void removeAgent(String agentName) throws ResourceNotFoundException {
        if (!agents.removeIf(agent -> agent.getName().equals(agentName)))
            throw new ResourceNotFoundException("Agent " + agentName + " not in account");
    }

    public boolean hasAgent(String name) {
        try {
            return getAgent(name) != null;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public Agent getAgent(String name) throws NoSuchElementException {
        return agents.stream().filter(agent -> agent.getName().equals(name)).findAny().get();
    }

}
