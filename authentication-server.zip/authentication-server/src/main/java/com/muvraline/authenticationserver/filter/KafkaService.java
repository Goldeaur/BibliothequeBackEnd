package com.muvraline.authenticationserver.filter;

import com.muvraline.authenticationserver.filter.event.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
public class KafkaService {

	@Value("${kafka.enabled}")
    private boolean enabled;

	@Value("${kafka.topic}")
	private String topic;
	
	@Autowired(required=false)
	private KafkaTemplate<String, Event> kafkaTemplate;

	public void sendMessageToKafka(Event msg) {

		Message<Event> message = MessageBuilder
				.withPayload(msg)
				.setHeader(KafkaHeaders.TOPIC, topic)
				.build();

		if(enabled) {
			kafkaTemplate.send(message);
		}
	}
}
