package com.muvraline.authenticationserver.filter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.time.ZoneId;
import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
public final class LoggerUtils {

    public static final String LOCAL_IP = getLocalIp();
    public static final String DEFAULT_IP = "127.0.0.1";
    public static final String UNKNOWN = "unknown";
    public static final String NULL_BODY = "{null}";
    public static final int THISPORT = 8082;
    public static final int UNKNOWN_DURATION = -1;
    public static final String TIME_ZONE = "Europe/Paris";
    public static final ZoneId ZONE_ID = ZoneId.of(TIME_ZONE);
    public static final String IGNORE_HEADER = "IgnoreLogging";
    public static final String LOCATION = "Location";
    public static final String toIgnore = "/actuator";
    public static final String ipsToIgnore = "10";
    public static final String CONTEXT_MAP = "context-map";
    public static final String START_TIME = "start-time";
    public static final String ID = "ID";
    public static final String AGENT_HEADER = "agent";
    public static final String SCENARIO_HEADER = "scenario";
    public static final String ACCOUNTID_HEADER = "accountId";
    public static final String HTTP_METHOD = "http_method";
    public static final String REMOTE_ADRESS = "Remote_address";
    public static final String REMOTE_IP = "Remote_IP";
    public static final String REMOTE_PORT = "Remote_port";
    public static final String XREQUESTID = "x-request-id";
    public static final String XB3TRACEID = "x-b3-traceid";
    public static final String XB3SPANID = "x-b3-spanid";
    public static final String XB3PARENTID = "x-b3-parentspanid";
    public static final String XB3SAMPLED = "x-b3-sampled";
    public static final String XB3FLAGS = "x-b3-flags";
    public static final String XOTSPANCONTEXT = "x-ot-span-context";
    public static final String XCONTEXT = "x-context";

    private static final ObjectMapper mapper = new ObjectMapper();

    public static final List<String> TO_PROPAGATE = Arrays.asList(XREQUESTID.toLowerCase(),
            XB3TRACEID.toLowerCase(),
            XB3SPANID.toLowerCase(),
            XB3PARENTID.toLowerCase(),
            XB3SAMPLED.toLowerCase(),
            XB3FLAGS.toLowerCase(),
            XCONTEXT.toLowerCase(),
            XOTSPANCONTEXT.toLowerCase());

    public static RequestContext getContext(String header){
        if(header != null){
            try {
                return mapper.readValue(Base64.getDecoder().decode(header), RequestContext.class);
            } catch (IOException e) {
                log.error("Error getting context : ", e.getMessage());
            }
        }
        return null;
    }

    private static String getLocalIp() {
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            return inetAddress.getHostAddress();
        }catch(Exception e) {
            return DEFAULT_IP;
        }
    }

    public static String getModule(int port) {
        String module = "";
        switch (port) {
            case 8081:
                module = "Botschoolinterface";
                break;
            case 8082:
                module = "ConfigurationManager";
                break;
            case 8083:
                module = "ScenarioManager";
                break;
            case 8084:
                module = "Rules";
                break;
            case 8085:
                module = "Collect";
                break;
            case 8086:
                module = "Habits";
                break;
            case 8087:
                module = "SkillManager";
                break;
            case 8088:
                module = "EventHandler";
                break;
            case 4200:
                module = "Client";
                break;
            default:
                module = "Unknown";
                break;
        }
        return module;
    }

    public static String getHttpMethod(Method method) {
        String httpMethod = UNKNOWN;
        for (Annotation annotation : method.getAnnotations()) {
            if (annotation instanceof PostMapping) {
                httpMethod = "POST";
                break;
            } else if (annotation instanceof GetMapping) {
                httpMethod = "GET";
                break;
            } else if (annotation instanceof PutMapping) {
                httpMethod = "PUT";
                break;
            } else if (annotation instanceof DeleteMapping) {
                httpMethod = "DELETE";
                break;
            } else if (annotation instanceof RequestMapping) {
                RequestMapping requestMapping = (RequestMapping) annotation;
                for (RequestMethod requestMethod : requestMapping.method()) {
                    httpMethod += requestMethod.name() + ",";
                }
                if (!httpMethod.equals("")) {
                }
                break;
            }
        }
        return httpMethod;
    }

    public static void propagateHeaders(HttpServletRequest request, HttpServletResponse response) {
        LoggerUtils.TO_PROPAGATE.forEach(key -> {
            String value = request.getHeader(key);
            if(value != null){
                response.addHeader(key, value);
            }
        });
    }

}
