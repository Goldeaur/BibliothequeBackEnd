package com.muvraline.authenticationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.muvraline.authenticationserver.AuthenticationserverApplication.ENV_TYPE;
import static com.muvraline.authenticationserver.filter.LoggerUtils.*;

@SpringBootApplication
@PropertySources({
		@PropertySource({ "classpath:configuration-${" + ENV_TYPE + ":docker}.properties" }),
})
public class AuthenticationserverApplication {

	public static final String ENV_TYPE = "ENVTYPE";
	
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setNullValue("");
        return propertySourcesPlaceholderConfigurer;
    }
	
	public static void main(String[] args) {
		SpringApplication.run(AuthenticationserverApplication.class, args);
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}


	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		List<ClientHttpRequestInterceptor> interceptorList = new ArrayList<ClientHttpRequestInterceptor>();
		interceptorList.add(new RestTemplateHeaderModifierInterceptor());
		restTemplate.setInterceptors(interceptorList);
		return restTemplate;
	}

	private class RestTemplateHeaderModifierInterceptor implements ClientHttpRequestInterceptor {

		@Override
		public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
				throws IOException {
			propagateHeaders(request);
			return execution.execute(request, body);
		}

		private void propagateHeaders(HttpRequest request) {
			RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
			HttpServletRequest httpRequest = ((ServletRequestAttributes)requestAttributes).getRequest();
			Map<String, String> headers = new HashMap<>();
			headers.put(XREQUESTID, httpRequest.getHeader(XREQUESTID));
			headers.put(XB3TRACEID, httpRequest.getHeader(XB3TRACEID));
			headers.put(XB3SPANID, httpRequest.getHeader(XB3SPANID));
			headers.put(XB3PARENTID, httpRequest.getHeader(XB3PARENTID));
			headers.put(XB3SAMPLED, httpRequest.getHeader(XB3SAMPLED));
			headers.put(XB3FLAGS, httpRequest.getHeader(XB3FLAGS));
			headers.put(XOTSPANCONTEXT, httpRequest.getHeader(XOTSPANCONTEXT));
			headers.entrySet().stream().forEach(entry -> {
				if(entry.getValue() != null) {
					request.getHeaders().add(entry.getKey(), entry.getValue());
				}
			});
		}
	}

}
