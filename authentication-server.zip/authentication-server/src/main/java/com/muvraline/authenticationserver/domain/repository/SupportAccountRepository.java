package com.muvraline.authenticationserver.domain.repository;

import com.muvraline.authenticationserver.domain.SupportAccount;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SupportAccountRepository extends MongoRepository<SupportAccount, String>, AccountRepository {
	
	public SupportAccount findByEmail(final String email);

}
