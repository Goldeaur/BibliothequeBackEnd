package com.muvraline.authenticationserver.oauth2.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class TokenResponse {

    @Builder.Default
    private String token_type = "Bearer";
    private String access_token;
    private String refresh_token;
    private long expires_in;

}
