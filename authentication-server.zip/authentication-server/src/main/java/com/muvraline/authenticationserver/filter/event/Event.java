package com.muvraline.authenticationserver.filter.event;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.muvraline.authenticationserver.filter.LoggerUtils;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonIgnoreProperties(ignoreUnknown = true, value = {"UNKNOWN", "NULL_BODY"})
@JsonInclude(value = Include.NON_NULL)
@ToString
public class Event {

    protected String accountId;

    protected String agent;

    protected String opCo;

    @Builder.Default
    protected String currentModule = "AuthenticationServer";

    protected String type;

    protected String location;

    protected String requestId;

    protected String httpMethod;

    protected String trigger;

    protected String usurper;

}
