package com.muvraline.authenticationserver.security;

import com.muvraline.authenticationserver.domain.Role;
import com.muvraline.authenticationserver.domain.UserDetailsCustom;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
@SuppressWarnings("unused")
public class CustomAuthenticationManager implements AuthenticationManager {

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = (String) authentication.getPrincipal();
        String password = (String) authentication.getCredentials();
        if (!(authentication instanceof CustomAuthentication)) {
            throw new BadCredentialsException("wrong type of authentication");
        }
        CustomAuthentication auth = (CustomAuthentication) authentication;
        UserDetails details = userDetailsService.loadUserByUsernameAndAgent(auth.getLogin(), auth.getAgent());
        authenticate(details, password);
        List<Role> roles = ((UserDetailsCustom) details).getRoles();
        Collection<GrantedAuthority> authorities = roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.name())).collect(Collectors.toSet());
        Authentication a = new UsernamePasswordAuthenticationToken(username, password, authorities);
        return a;
    }

    public void validateUserDetails(UserDetails userDetails) throws DisabledException {
        if (!userDetails.isEnabled()) {
            log.error("User disable {}",userDetails.getUsername());
            throw new DisabledException("User is disabled");
        }
    }

    //Check dans le bon ordre ?
    public void authenticate(UserDetails userDetails, String password) {
        if (userDetails == null || !passwordEncoder.matches(password, userDetails.getPassword())) {
            log.error("Invalid credentials : {}", userDetails.getUsername());
            throw new BadCredentialsException("Invalid credentials");
        }
        validateUserDetails(userDetails);
    }

}
