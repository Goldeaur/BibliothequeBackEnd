package com.muvraline.authenticationserver.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ControllerUtils {

    private static final ObjectMapper mapper = new ObjectMapper();


    public static ObjectNode jsonErrorFromString(String message){
        return mapper.createObjectNode().put("error",message);
    }

    public static ObjectNode jsonErrorFromException(Exception e){
        return mapper.createObjectNode().put("error", e.getMessage());
    }
}
