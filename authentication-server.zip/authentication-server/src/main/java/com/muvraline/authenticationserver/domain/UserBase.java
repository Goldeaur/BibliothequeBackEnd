package com.muvraline.authenticationserver.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;

@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
class UserBase extends BaseInfo {
    @JsonProperty(required = true)
    protected String accountId;

    @Setter
    protected RgpdChoices rgpdChoices;

    @JsonProperty(required = true)
    protected OpCo opCo;
}
