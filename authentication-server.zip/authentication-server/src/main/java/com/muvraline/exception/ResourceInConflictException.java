package com.muvraline.exception;

public class ResourceInConflictException  extends Exception{
	private static final long serialVersionUID = 1L;
	public ResourceInConflictException(String message) {
		super(message);
	}
}
