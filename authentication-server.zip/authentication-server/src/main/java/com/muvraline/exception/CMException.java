package com.muvraline.exception;

public class CMException extends Exception{
    private static final long serialVersionUID = 1L;
    public CMException(String message) {
        super(message);
    }

    public CMException(Throwable ex){
        super(ex);
    }
}
