package com.muvraline.exception;

public class HeaderMissingException extends Exception {
    public HeaderMissingException(String message){
        super(message);
    }
}
