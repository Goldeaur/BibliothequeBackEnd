package com.muvraline.exception;

public class RoleNotAllowedException extends Exception{
	private static final long serialVersionUID = 1L;
	public RoleNotAllowedException(String message) {
		super(message);
	}
}