#!/bin/bash
kubectl delete deploy/nico -n dev
telepresence --new-deployment nico --namespace dev
#telepresence --new-deployment nico --namespace ci-homebot-tests-845a16ae
