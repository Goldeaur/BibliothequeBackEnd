#!/bin/bash
kubectl delete deploy/nico -n dev
telepresence --swap-deployment authenticationserver --namespace dev
